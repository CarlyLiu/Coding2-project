#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
	ofSetVerticalSync(true);
	
	int num = 1200;
	p.assign(num, demoParticle());
    
	currentMode = PARTICLE_MODE_NOISE;

	currentModeStr = "rain particle simulation :)";

	resetParticles();
    
    ofSetWindowTitle("In the Rain");
    ofSetFrameRate(60);


    gui.setup(); // most of the time you don't need a name
    gui.add(filled.setup("Light", true));
    gui.add(radius.setup("Speed", 4, 1, 10));

    bHide = false;
    
    
}

//--------------------------------------------------------------
void ofApp::circleResolutionChanged(int &circleResolution){
    ofSetCircleResolution(circleResolution);
}

//--------------------------------------------------------------
void ofApp::resetParticles(){

	//these are the attraction points used in the forth demo 
	attractPoints.clear();
	for(int i = 0; i < 4; i++){
		attractPoints.push_back( glm::vec3( ofMap(i, 0, 4, 100, ofGetWidth()-100) , ofRandom(100, ofGetHeight()-100) , 0) );
	}
	
	attractPointsWithMovement = attractPoints;
	
	for(unsigned int i = 0; i < p.size(); i++){
		p[i].setMode(currentMode);		
		p[i].setAttractPoints(&attractPointsWithMovement);;
		p[i].reset();
	}
}

//--------------------------------------------------------------
void ofApp::update(){
    
    speed = int(radius);
    
    
    //----------------------------
	for(unsigned int i = 0; i < p.size(); i+=3){
		p[i].setMode(currentMode);
        p[i].update();
        p[i+1].update2(speed);
		p[i+2].update3(speed);
	}
	
	//lets add a bit of movement to the attract points
	for(unsigned int i = 0; i < attractPointsWithMovement.size(); i++){
		attractPointsWithMovement[i].x = attractPoints[i].x + ofSignedNoise(i * 10, ofGetElapsedTimef() * 0.7) * 12.0;
		attractPointsWithMovement[i].y = attractPoints[i].y + ofSignedNoise(i * -10, ofGetElapsedTimef() * 0.7) * 12.0;
	}
    //--------------------------
    
}

//--------------------------------------------------------------
void ofApp::draw(){
   
    ofSetBackgroundColorHex(0x313577);

    //int receive= int(receivedData);
    
    
    
	for(unsigned int i = 0; i < p.size(); i++){
        p[i].draw(speed);
	}

//    ofSetHexColor(0xffffff);
//    ofFill();        // draw "filled shapes"
//    ofDrawCircle(mouseX,mouseY,100);
    ofSetHexColor(0x313577);
    output.fill();
    output.arc(mouseX,mouseY,100, 0, -180);

    output.noFill();
    output.setColor(0xf8f8f8f8);
    output.arc(mouseX,mouseY,100, 0, -180);
    output.arc(mouseX-15,mouseY+100,15, 0, 180);
    output.bezier(mouseX,mouseY-100,mouseX-60,mouseY-80,mouseX-70,mouseY, mouseX-70,mouseY);
    output.bezier(mouseX,mouseY-100,mouseX+60,mouseY-80,mouseX+70,mouseY, mouseX+70,mouseY);
    output.line(mouseX,mouseY-110,mouseX,mouseY+100);
    output.line(mouseX-100,mouseY,mouseX+100,mouseY);

    string msg;
    msg += "got speed = ";
    //msg += receivedData;
    msg += "\n";
    //msg += Pct;
    
	ofSetColor(230);	
	ofDrawBitmapString(currentModeStr + "\n\nSpacebar to reset.", 10, 620);
    ofDrawBitmapString(msg, 10, 680);
    ofDrawBitmapString(speed, 10, 700);
    
    
    if(filled){
        ofFill();
    }else{
        ofNoFill();
    }
    
    if(!bHide){
        gui.draw();
    }
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
		
	if( key == ' ' ){
		resetParticles();
	}
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
